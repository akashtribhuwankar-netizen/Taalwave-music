# TAALWAVE Android App

A native Android music player starter built with Kotlin, Jetpack Compose and AndroidX Media3.

## Current features
- Dark TAALWAVE home screen
- Reads music files stored on the device (after permission is granted)
- Search local tracks by title or artist
- Like/unlike tracks in the in-memory favourites list
- Playback with ExoPlayer and a mini-player
- Previous/next controls

## Build an APK in the cloud (no laptop required, but a GitHub account is needed)
1. Create a new empty repository on GitHub.
2. Upload the **contents** of this project folder to the repository root (not the ZIP file itself).
3. Open the repository's **Actions** tab and select **Build Taalwave APK**.
4. Tap **Run workflow**. Wait for the workflow to finish successfully.
5. Open the completed run and download the `Taalwave-debug-apk` artifact.
6. Extract the downloaded artifact on your Android phone and install `app-debug.apk`. Android may ask you to allow installs from that browser/file manager.

The workflow builds a debug APK. It is suitable for testing, not a Play Store release.

## Important scope note
This first build plays audio already stored on the phone. It does not yet include a licensed online music catalogue, accounts, cloud playlists, or subscription payments. Those require a backend and music-streaming rights.
