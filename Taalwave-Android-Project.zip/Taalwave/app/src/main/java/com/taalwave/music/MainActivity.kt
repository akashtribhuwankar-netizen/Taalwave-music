package com.taalwave.music

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import android.net.Uri

private val Ink = Color(0xFF101512)
private val Panel = Color(0xFF1B2420)
private val Mint = Color(0xFF22D3A6)
private val Muted = Color(0xFF9BAAA3)

data class Track(val id: Long, val title: String, val artist: String, val uri: Uri)

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer
    private var tracks by mutableStateOf<List<Track>>(emptyList())
    private var permissionGranted by mutableStateOf(false)
    private var playingIndex by mutableIntStateOf(-1)
    private var isPlaying by mutableStateOf(false)

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permissionGranted = granted
        if (granted) loadTracks()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        permissionGranted = ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
        if (permissionGranted) loadTracks()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Mint, background = Ink, surface = Panel)) {
                TaalwaveApp(
                    tracks = tracks,
                    permissionGranted = permissionGranted,
                    playingIndex = playingIndex,
                    isPlaying = isPlaying,
                    onRequestPermission = { permissionLauncher.launch(permission) },
                    onPlay = { index -> playTrack(index) },
                    onToggle = { if (player.isPlaying) player.pause() else player.play(); isPlaying = player.isPlaying },
                    onNext = { if (tracks.isNotEmpty()) playTrack((playingIndex + 1).mod(tracks.size)) },
                    onPrevious = { if (tracks.isNotEmpty()) playTrack(if (playingIndex <= 0) tracks.lastIndex else playingIndex - 1) }
                )
            }
        }
    }

    private fun loadTracks() {
        val result = mutableListOf<Track>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST)
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        contentResolver.query(collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} ASC")?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val uri = ContentUris.withAppendedId(collection, id)
                result += Track(id, cursor.getString(titleCol) ?: "Unknown track", cursor.getString(artistCol) ?: "Unknown artist", uri)
            }
        }
        tracks = result
    }

    private fun playTrack(index: Int) {
        if (index !in tracks.indices) return
        playingIndex = index
        player.setMediaItem(MediaItem.fromUri(tracks[index].uri))
        player.prepare()
        player.play()
        isPlaying = true
    }

    override fun onDestroy() { player.release(); super.onDestroy() }
}

@Composable
private fun TaalwaveApp(
    tracks: List<Track>, permissionGranted: Boolean, playingIndex: Int, isPlaying: Boolean,
    onRequestPermission: () -> Unit, onPlay: (Int) -> Unit, onToggle: () -> Unit,
    onNext: () -> Unit, onPrevious: () -> Unit
) {
    var tab by remember { mutableStateOf("Home") }
    var query by remember { mutableStateOf("") }
    var favourites by remember { mutableStateOf(setOf<Long>()) }
    val current = tracks.getOrNull(playingIndex)
    Scaffold(containerColor = Ink, bottomBar = {
        NavigationBar(containerColor = Color(0xFF151D19), contentColor = Color.White) {
            NavigationBarItem(selected = tab == "Home", onClick = { tab = "Home" }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
            NavigationBarItem(selected = tab == "Search", onClick = { tab = "Search" }, icon = { Icon(Icons.Default.Search, null) }, label = { Text("Search") })
            NavigationBarItem(selected = tab == "Library", onClick = { tab = "Library" }, icon = { Icon(Icons.Default.LibraryMusic, null) }, label = { Text("Library") })
        }
    }) { padding ->
        Column(Modifier.fillMaxSize().background(Ink).padding(padding)) {
            Column(Modifier.weight(1f).fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("TAALWAVE", color = Mint, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                        Text("Feel every beat.", color = Muted, fontSize = 12.sp)
                    }
                    Box(Modifier.size(42.dp).background(Panel, CircleShape), contentAlignment = Alignment.Center) { Text("TW", color = Mint, fontWeight = FontWeight.Bold) }
                }
                when (tab) {
                    "Search" -> {
                        OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp), placeholder = { Text("Songs, artists...") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true, shape = RoundedCornerShape(18.dp))
                        TrackList(tracks.filter { it.title.contains(query, true) || it.artist.contains(query, true) }, tracks, playingIndex, favourites, { favourites = if (it in favourites) favourites - it else favourites + it }, onPlay)
                    }
                    "Library" -> {
                        Text("Your Library", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
                        Text("Liked songs · ${favourites.size}", color = Muted, modifier = Modifier.padding(horizontal = 20.dp))
                        TrackList(tracks.filter { it.id in favourites }, tracks, playingIndex, favourites, { favourites = if (it in favourites) favourites - it else favourites + it }, onPlay)
                    }
                    else -> {
                        Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(166.dp).background(Brush.linearGradient(listOf(Color(0xFF174D3F), Color(0xFF17251F), Color(0xFF263C32))), RoundedCornerShape(24.dp)).padding(20.dp)) {
                            Column(Modifier.align(Alignment.CenterStart)) {
                                Text("YOUR SOUND. YOUR WORLD.", color = Mint, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                                Spacer(Modifier.height(8.dp))
                                Text("Find your\nnext favourite.", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 30.sp)
                            }
                            Text("♫", color = Color.White.copy(alpha = .12f), fontSize = 100.sp, modifier = Modifier.align(Alignment.CenterEnd))
                        }
                        Text("Made for your mood", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 20.dp, top = 22.dp, bottom = 10.dp))
                        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            MoodCard("Chill", "Slow it down", Color(0xFF244B5B), Modifier.weight(1f))
                            MoodCard("Energy", "Feel the beat", Color(0xFF5A352B), Modifier.weight(1f))
                        }
                        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("On this device", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text("${tracks.size} tracks", color = Muted, fontSize = 12.sp)
                        }
                        if (!permissionGranted) {
                            Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Allow audio access to find music on your phone.", color = Muted)
                                Button(onClick = onRequestPermission) { Text("Allow access") }
                            }
                        } else if (tracks.isEmpty()) {
                            Text("No audio files found yet. Add music to your phone and refresh the app.", color = Muted, modifier = Modifier.padding(20.dp))
                        } else TrackList(tracks, tracks, playingIndex, favourites, { favourites = if (it in favourites) favourites - it else favourites + it }, onPlay)
                    }
                }
            }
            if (current != null) MiniPlayer(current.title, current.artist, isPlaying, onToggle, onNext)
        }
    }
}

@Composable
private fun MoodCard(title: String, subtitle: String, color: Color, modifier: Modifier = Modifier) {
    Column(modifier.height(100.dp).background(color, RoundedCornerShape(18.dp)).padding(14.dp), verticalArrangement = Arrangement.Bottom) {
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(subtitle, color = Color.White.copy(alpha = .75f), fontSize = 11.sp)
    }
}

@Composable
private fun TrackList(items: List<Track>, allTracks: List<Track>, playingIndex: Int, favourites: Set<Long>, onFavourite: (Long) -> Unit, onPlay: (Int) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(bottom = 12.dp)) {
        itemsIndexed(items, key = { _, track -> track.id }) { _, track ->
            val index = allTracks.indexOfFirst { it.id == track.id }
            Row(Modifier.fillMaxWidth().clickable { onPlay(index) }.padding(horizontal = 18.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(48.dp).background(Brush.linearGradient(listOf(Color(0xFF245B4B), Color(0xFF26332D))), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Text("♫", color = Mint, fontSize = 24.sp) }
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    Text(track.title, color = if (index == playingIndex) Mint else Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(track.artist, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = { onFavourite(track.id) }) { Icon(Icons.Default.Favorite, null, tint = if (track.id in favourites) Mint else Muted) }
            }
        }
    }
}

@Composable
private fun MiniPlayer(title: String, artist: String, isPlaying: Boolean, onToggle: () -> Unit, onNext: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp).background(Panel, RoundedCornerShape(16.dp)).padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).background(Color(0xFF245B4B), RoundedCornerShape(9.dp)), contentAlignment = Alignment.Center) { Text("♫", color = Mint, fontSize = 20.sp) }
        Column(Modifier.weight(1f).padding(start = 10.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp)
            Text(artist, color = Muted, fontSize = 11.sp, maxLines = 1)
        }
        IconButton(onClick = onToggle) { Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White) }
        IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, null, tint = Color.White) }
    }
}
